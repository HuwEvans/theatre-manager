<?php
/**
 * Theatre Manager Gutenberg Blocks Registration
 * 
 * Registers and enqueues all custom Gutenberg blocks
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Register Theatre Manager Gutenberg blocks
 * 
 * Called on 'init' hook after WordPress is fully loaded
 */
function tm_register_gutenberg_blocks() {
    $blocks = [
        'blocks/tm-landingpage-block'
    ];

    foreach ($blocks as $block_dir) {
        $block_path = TM_PLUGIN_DIR . $block_dir;
        
        // Check if block.json exists
        if (file_exists($block_path . '/block.json')) {
            register_block_type($block_path);
        }
    }
}
add_action('init', 'tm_register_gutenberg_blocks');

/**
 * Enqueue block editor assets
 * 
 * Compiles SCSS and enqueues block scripts/styles
 */
function tm_enqueue_block_assets() {
    // Only enqueue on the editor
    if (!is_admin()) {
        return;
    }

    $block_path = TM_PLUGIN_DIR . 'blocks/tm-landingpage-block';
    
    // Build paths
    $script_asset_path = $block_path . '/index.asset.php';
    $style_path = $block_path . '/editor.scss';
    $script_path = $block_path . '/index.js';

    // Load asset metadata for dependencies and version
    $script_asset = file_exists($script_asset_path)
        ? include($script_asset_path)
        : ['dependencies' => ['wp-blocks', 'wp-element', 'wp-components', 'wp-editor'], 'version' => THEATRE_MANAGER_VERSION];

    // Enqueue editor script
    wp_enqueue_script(
        'tm-landingpage-block-editor',
        TM_PLUGIN_URL . 'blocks/tm-landingpage-block/index.js',
        $script_asset['dependencies'],
        $script_asset['version'],
        true
    );

    // Enqueue editor styles (will be compiled from SCSS)
    wp_enqueue_style(
        'tm-landingpage-block-editor',
        TM_PLUGIN_URL . 'assets/css/blocks-editor.css',
        [],
        THEATRE_MANAGER_VERSION
    );
}
add_action('enqueue_block_editor_assets', 'tm_enqueue_block_assets');

/**
 * Allow show post type to be queryable via REST API
 * This enables the block's show search functionality
 */
function tm_update_show_rest_support() {
    $args = get_post_type_object('show');
    if ($args) {
        $args->show_in_rest = true;
        register_post_type('show', $args);
    }
}
add_action('init', 'tm_update_show_rest_support', 11); // Run after show CPT is registered
